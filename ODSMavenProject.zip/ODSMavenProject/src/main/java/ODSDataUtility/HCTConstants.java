package ODSDataUtility;

public class HCTConstants {
	private HCTConstants() {
		throw new IllegalStateException("Utility class");
	}

	public static final String SUCCESS = "SUCCESS";
	public static final String PENDING = "PENDING";
	public static final String FAILURE = "FAILURE";
	public static final String INPROGRESS = "INPROGRESS";
	public static final String COMPLETED = "COMPLETED";

	public static final String AUTH_FAILURE = "Authentication Failure";
	public static final String FETCH_SUCCESS = "Records found for given criteria";
	public static final String FETCH_FAILURE = "No records found for given criteria";
	public static final String VALIDATION_FAILURE = "Validation failure or unable to read data";
	public static final String UPLOAD_SUCCESS = "File uploaded successfully";
	public static final String INVALID_BATCHID_INPUT = "Invalid batchId provided";
	public static final String EVENT_UPLOAD_SUCCESS = "Event pushed successfully";
	public static final String USER_PROPERTIES_UPLOAD_SUCCESS = "User properties pushed successfully";
	
	public static final String EVENT = "event";
	public static final String ODS = "ODS";
	public static final String ACTIVEDAYYEARPOLICY = "ACTIVEDAYYEARPOLICY";
	public static final String WELLNESS = "WELLNESS";
	public static final String MULTIPLY = "MULTIPLY";
	public static final String HEALTH = "HEALTH";
	public static final String STEP_DATA_EVENT_CODE = "ED-Step_Event";
	public static final String CALORIE_DATA_EVENT_CODE = "ED-Calorie_Event";
	public static final String STEP_DATA_VALUE_FIELD_NAME = "steps";
	public static final String CALORIE_DATA_VALUE_FIELD_NAME = "calories";
	public static final String ACTIVE_DAYS_MULTIPLY = "ACTIVE_DAYS_MULTIPLY";
}
