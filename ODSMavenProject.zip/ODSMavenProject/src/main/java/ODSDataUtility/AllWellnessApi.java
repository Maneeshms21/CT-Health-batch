package ODSDataUtility;

import java.io.IOException;
import java.text.ParseException;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

//import com.ct.incin.health.request.AdminConfig;

import com.google.gson.Gson;

import ODSData.Request.ConfigResponse;

public class AllWellnessApi {
	public static  String callAdminApi(String key ) throws ParseException, IOException { 
		  String configValue=null;
		  CloseableHttpClient httpClient;
		  System.out.println("Inside callAdminApi method");
		  try {
				 httpClient = HttpClients.createDefault();
				 StringBuilder produrl= new StringBuilder("https://wellnesspre.adityabirlahealth.com/AdminUtilityAPI/rest/config/findbykey/") .append(key); 
			  StringBuilder preurl= new StringBuilder("https://wellnesspre.adityabirlahealth.com/AdminUtilityAPI/rest/config/findbykey/") .append(key);
			  System.out.println("url- "+preurl);
			  HttpGet request = new HttpGet(preurl.toString());
				
		
			  //add request headers 
			  request.addHeader("content-type", "application/json"); 
			  request.addHeader("accessid", "7860229b-fdc6-479d-9288-6c750d21cf6c"); 

				 CloseableHttpResponse response = httpClient.execute(request);
				 
				
				  HttpEntity entity = response.getEntity(); 
				  if (entity != null)
				  { 
						  String result = EntityUtils.toString(entity);
						  System.out.println("callAdminApi result "+result);
						  ConfigResponse jsonresp = new  Gson().fromJson(result, ConfigResponse.class); 
						   configValue= jsonresp.configs.get(0).getValue() ;
						  System.out.println(configValue+" configValue");
						  return configValue;
				}  
		  } catch(NullPointerException e)
		  {
			  System.out.println("No config key found "+e);
			 // e.printStackTrace();
		  }
		
		  return configValue; 
		  } 

	
	 public static void callAdminApiforUpdate(String key,String value) throws IOException {
		 String configValue=null;
		  CloseableHttpClient httpClient;
		  System.out.println("Inside callAdminApi method");
		  try {
				 httpClient = HttpClients.createDefault();
	    		 String produrl= ("https://wellnesspre.adityabirlahealth.com/AdminUtilityAPI/rest/config/update"); 
				 String preurl=("https://wellnesspre.adityabirlahealth.com/AdminUtilityAPI/rest/config/update");
				  System.out.println("url- "+preurl);
				  HttpPut request = new HttpPut(preurl);
				String encrypted="false";
				request.addHeader("content-type", "application/json"); 
				  request.addHeader("accessid", "7860229b-fdc6-479d-9288-6c750d21cf6c");
				  request.addHeader("accessid", "7860229b-fdc6-479d-9288-6c750d21cf6c"); 

				  String jsonrequest = "{" +  "\""+ "key" +  "\"" + ":" +  "\"" +key + "\"" + "," + "\"" + "value" +  "\"" + ":" +  "\"" +value +  "\"" +  "," + "\""+ "encrypted" +  "\"" + ":" +encrypted + "}";
				  System.out.println(jsonrequest);
	            StringEntity stringEntity = new StringEntity(jsonrequest);
	            request.setEntity(stringEntity);
	            CloseableHttpResponse response = httpClient.execute(request);
	            System.out.println("Executing request " + request.getRequestLine());

	      	  HttpEntity entity = response.getEntity(); 
			  if (entity != null)
			  { 
					  String result = EntityUtils.toString(entity);
					  System.out.println("callAdminApi result "+result);
					  ConfigResponse jsonresp = new  Gson().fromJson(result, ConfigResponse.class); 
					  configValue= jsonresp.configs.get(0).getValue() ;
					  System.out.println(configValue+" configValue");
			}  
	        }
		  catch(NullPointerException e)
		  {
			  System.out.println("No config key found "+e);
		  }
	    }
	

}
