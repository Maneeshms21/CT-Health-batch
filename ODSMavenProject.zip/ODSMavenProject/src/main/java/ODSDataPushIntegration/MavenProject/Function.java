package ODSDataPushIntegration.MavenProject;


import com.google.gson.Gson;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;

import ODSData.Request.ClevertapUploadUserPropertyRequest;
import ODSData.Request.ClevertapUserPropertyData;
import ODSData.Request.OdsDataCT;
import ODSData.Request.PushUserPropertiesRequest;
import ODSDataUtility.AllWellnessApi;
import ODSDataUtility.HCTConstants;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.net.ssl.HttpsURLConnection;

/**
 * Azure Functions with HTTP Trigger.
 */
public class Function {
	public static final String CLEVERTAP_UPLOAD_EVENT_URL = "CLEVERTAP_UPLOAD_EVENT_URL";
	public static final String CLEVERTAP_ACCOUNT_ID = "CLEVERTAP_ACCOUNT_ID";
	public static final String CLEVERTAP_HEALTH_ACCOUNT_ID = "CLEVERTAP_HEALTH_ACCOUNT_ID";
	public static final String CLEVERTAP_PASSCODE = "CLEVERTAP_PASSCODE";
	public static final String CLEVERTAP_HEALTH_PASSCODE = "CLEVERTAP_HEALTH_PASSCODE";
	public static final String PROXY_ENABLED = "PROXY_ENABLED";
	public static final String INVGEN_ACCESSID = "INVGEN_ACCESSID";
	public static final String CT_ODS_CREATED_DATE_FORMAT = "CT_ODS_CREATED_DATE_FORMAT";
	public static final String CT_ODS_DATABASE_CONN_STRING = "CT_ODS_DATABASE_CONN_STRING";
	public static final String HEALTHCOMM_LAST_RUN_TIME = "HEALTHCOMM_LAST_RUN_TIME";
	public static final String CT_ODS_DATABASE_CONN_USERID = "CT_ODS_DATABASE_CONN_USERID";
	public static final String CT_ODS_DATABASE_CONN_PASSWORD = "CT_ODS_DATABASE_CONN_PASSWORD";
	public static final String CT_ODS_RUNTIME_DATA_LIMIT = "CT_ODS_RUNTIME_DATA_LIMIT";
	
    /**
     * This function listens at endpoint "/api/HttpExample". Two ways to invoke it using "curl" command in bash:
     * 1. curl -d "HTTP Body" {your host}/api/HttpExample
     * 2. curl "{your host}/api/HttpExample?name=HTTP%20Query"
     * @throws IOException 
     * @throws ParseException 
     */
    @FunctionName("odsdatapush")
    public HttpResponseMessage run( @HttpTrigger(name = "req",methods = { HttpMethod.POST},  authLevel = AuthorizationLevel.ANONYMOUS) HttpRequestMessage<Optional<String>> request,
            final ExecutionContext context) throws ParseException, IOException {
        context.getLogger().info("CT data push batch stated");
        String lastRundate = AllWellnessApi.callAdminApi(HEALTHCOMM_LAST_RUN_TIME);
        final String query = request.getQueryParameters().get(lastRundate);
         String lastRundate1 = request.getBody().orElse(query);
        
        
    	Date lastRunTime=convertToDate(lastRundate, "yyyy-MM-dd HH:mm:ss");
    	String connurl="jdbc:sqlserver://abhil-p-synapse.sql.azuresynapse.net:1433;DatabaseName=abhiods";
    	String username="thbdata";
    	String pass="T!h@b$d@t@1122";
    	context.getLogger().info("lastRunTime "+lastRunTime);
		System.out.println("lastRunTime "+lastRunTime);
        if (lastRundate == null) {
            return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body("Please pass a name on the query string or in the request body").build();
        } else {
        	GetOdsData(connurl,	username,	pass, lastRunTime, context);
            return request.createResponseBuilder(HttpStatus.OK).body("Ct Data Push Completed at  " + lastRunTime).build();
        }
    }
    
	
	/*  public static void main(String[] args) throws Exception {
	  System.out.println("My name is Maneesh"); 
	  Date date=new Date(); 
	  //Calendar c=new Calendar();
	  String lastRundate =AllWellnessApi.callAdminApi(HEALTHCOMM_LAST_RUN_TIME);
	  System.out.println("lastRundate "+lastRundate); String
	  lastRun="2023-01-09 23:00:00"; 
	  Date lastRunTime=convertToDate(lastRun,"yyyy-MM-dd HH:mm:ss"); 
	  System.out.println("lastRunTime "+lastRunTime);
	  //ExecutionContext context ;
	  //context.getLogger().info("Java HTTP trigger processed a request.");
  	String connurl="jdbc:sqlserver://abhil-p-synapse.sql.azuresynapse.net:1433;DatabaseName=abhiods";
  	String username="thbdata";
  	String pass="T!h@b$d@t@1122";
	  //GetOdsData(connurl,			  username, pass, lastRunTime, context); }
	 
	  }*/
     public  static  void GetOdsData( String db_connect_string, String db_userid, String db_password, Date date,ExecutionContext context) {
		// TODO Auto-generated method stub
    	 context.getLogger().info("inside GetOdsData method ");
		Connection conn = null;
		List<OdsDataCT> odsDataCT = new ArrayList<OdsDataCT>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
		String strDate = dateFormat.format(date);  
		String HEALTH_CT_REPLICATION_PROP="POLICY_START_DATE,POLICY_END_DATE,POLICY_VARIANT,PRODUCT_NAME,PLAN_TYPE,POLICY_NUMBER,NUMBER_OF_MEMBERS,SUM_INSURED,PROPOSAL_SUBSTATUS,IntermediaryCode,IntermediaryName,IntermediaryCategory,ParentServiceProviderName,Channel,IS_PROPOSER,NET_PREMIUM,AUTODEBIT,Category,Risk_Category";
		//context.getLogger().info("inside GetOdsData method HEALTH_CT_REPLICATION_PROP "+HEALTH_CT_REPLICATION_PROP);
		System.out.println("strDate "+strDate);
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(db_connect_string, db_userid, db_password);
			System.out.println("connected");
			context.getLogger().info("connected");
			Statement statement = conn.createStatement();
			String ExecuteQuery= "select * FROM BI.THB_DATA WHERE CreatedDate>='"+ strDate +"' ";
					//+ " OFFSET "+NewOds.getStartValue()+" ROWS FETCH NEXT "+LIMIT+" ROWS ONLY ";
			
		     if(ExecuteQuery!=null) {
			 //logProcessorService.addNewTransactionDetails(txId,LogType.LOG_TYPE_INFO ,"Ods get data in 50 count batch started "," at "+new Date()+ExecuteQuery  );
			 System.out.println("Ods get data  batch started  at "+new Date()+ExecuteQuery );
			 context.getLogger().info("Ods get data  batch started  at "+new Date()+ExecuteQuery );
			 ResultSet rs = statement.executeQuery(ExecuteQuery);
			 
			 while (rs.next()) {
					OdsDataCT ODT=new OdsDataCT();
					try {
//						 ODT=new OdsDataCT();
						Map<String,Object> data=new HashMap<String, Object>();
						
				        List<String> replicatedAttribute=Arrays.asList(HEALTH_CT_REPLICATION_PROP.split(","));
				        fetchOdsDataFromResultSet(rs, data,replicatedAttribute );
					
				        ODT.setCustomerId(rs.getString("MEMBERCODE"));
						ODT.setMemberReferenceNumber(rs.getString("MEMBERCODE"));
						ODT.setData(data);
					} catch (Exception e) {
						System.out.println("Exception "+e);
						context.getLogger().info("Exception "+e);
						//logProcessorService.addNewTransactionDetails(txId,LogType.LOG_TYPE_INFO ,"Error ",ExceptionUtils.getFullStackTrace(e));
					}
					if(ODT!=null) {
						odsDataCT.add(ODT);
					}
				}
			 
			        if(odsDataCT!=null) {
					for(OdsDataCT lst:odsDataCT) {
						try {
							lst.setSource(HCTConstants.HEALTH);
							pushUserProperties(new Gson().toJson(lst), HCTConstants.HEALTH, context);
							 //context.getLogger().info("ODS BATCH PUSH TO CT Success"+new Gson().toJson(lst));
							System.out.println("ODS BATCH PUSH TO CT Success"+new Gson().toJson(lst));
						      Date CurruntDate = new Date();

								//if (CurruntDate.compareTo(lastRunTime) > 0) {
						        String lastRundate = AllWellnessApi.callAdminApi(HEALTHCOMM_LAST_RUN_TIME);

								String newlastRundate = (convertToString(CurruntDate,AllWellnessApi.callAdminApi(CT_ODS_CREATED_DATE_FORMAT)));
								AllWellnessApi.callAdminApiforUpdate(HEALTHCOMM_LAST_RUN_TIME, newlastRundate);
						} catch (Exception e) {
							System.out.println("ODS BATCH PUSH TO CT failed"+new Gson().toJson(lst));
							//context.getLogger().info("ODS BATCH PUSH TO CT failed"+new Gson().toJson(lst));
							e.printStackTrace();
						}
					}}
					odsDataCT.clear();
					//context.getLogger().info("=======================");
					System.out.println("=======================");
			 }
		}catch(Exception e)
		{
			System.out.println("Error occurred "+e);
			//context.getLogger().info("Error occurred "+e);
		}
		
	}
	public static void pushUserProperties(String message, String app,ExecutionContext context) {
		if (message != null) {
			PushUserPropertiesRequest userPropertiesRequest = new Gson().fromJson(message,
					PushUserPropertiesRequest.class);
			if(userPropertiesRequest.getData().containsKey("Age_1")) {
			userPropertiesRequest.getData().put("Age_1",new Double(String.valueOf(userPropertiesRequest.getData().get("Age_1"))).intValue());
			}
			if (userPropertiesRequest != null && userPropertiesRequest.getData() != null &&
					(userPropertiesRequest.getCustomerId()!=null || userPropertiesRequest.getMemberReferenceNumber()!= null)) {
				ClevertapUploadUserPropertyRequest r = convert(userPropertiesRequest, context);
				
				if(userPropertiesRequest.getSource()!=null) {
					pushPropertiesToCleverTap(r, userPropertiesRequest.getSource(),  context);
				}else {
					System.out.println("Unable to push property to clevertap source null"+message);
					//context.getLogger().info("Unable to push property to clevertap source null"+message);
				}
				
				
			}else {
				System.out.println("Unable to push property to clevertap Data ignored"+message);
				//context.getLogger().info("Unable to push property to clevertap Data ignored"+message);

			}
		}

	}

	private static ClevertapUploadUserPropertyRequest convert(PushUserPropertiesRequest userPropertiesRequest,ExecutionContext context) {
		ClevertapUploadUserPropertyRequest result = null;
		if (userPropertiesRequest != null) {
			result = new ClevertapUploadUserPropertyRequest();
			List<ClevertapUserPropertyData> d = new ArrayList<ClevertapUserPropertyData>();
			ClevertapUserPropertyData data = new ClevertapUserPropertyData();

			
			if(userPropertiesRequest.getMemberReferenceNumber()!=null && userPropertiesRequest.getSource().equalsIgnoreCase(HCTConstants.HEALTH)) {
				data.setIdentity(userPropertiesRequest.getMemberReferenceNumber() + "");
			}

			data.setType("profile");
			data.setProfileData(userPropertiesRequest.getData());
			//context.getLogger().info("userPropertiesRequest.getData() "+userPropertiesRequest.getData());
			d.add(data);
			System.out.println("userPropertiesRequest.getData() "+userPropertiesRequest.getData());
			result.setD(d);
		}
		return result;
	}


	public static void pushPropertiesToCleverTap(ClevertapUploadUserPropertyRequest r, String app,ExecutionContext context) {
	
		if (r != null) {
			try {
				if(app.equalsIgnoreCase(HCTConstants.HEALTH)) {
					String response =POSTRequest(new Gson().toJson(r), context);//,context);
					System.out.println("response "+response+" new Gson().toJson(r) "+new Gson().toJson(r));
					context.getLogger().info("response "+response+" new Gson().toJson(r) "+new Gson().toJson(r));
				} 
		}
		catch(Exception e)
		{
			context.getLogger().info("Error in pushPropertiesToCleverTap method " +e);
			System.out.println("Error in pushPropertiesToCleverTap method " +e);
		}}
		else {
			System.out.println("Unable to push user properties to clevertap could not create request object");
			context.getLogger().info("Unable to push user properties to clevertap could not create request object");
		}
	}
	public static String POSTRequest(String POST_PARAMS,ExecutionContext context)  {
		String ajaxResponse =null;

		try {
	    		 
	    URL obj = new URL("https://in1.api.clevertap.com/1/upload");
	    HttpsURLConnection postConnection = (HttpsURLConnection) obj.openConnection();
	    postConnection.setRequestMethod("POST");
	    postConnection.setRequestProperty("X-CleverTap-Passcode", AllWellnessApi.callAdminApi(CLEVERTAP_HEALTH_PASSCODE));
	    postConnection.setRequestProperty("X-CleverTap-Account-Id",AllWellnessApi.callAdminApi(CLEVERTAP_HEALTH_ACCOUNT_ID));
	    postConnection.setRequestProperty("Content-Type", "application/json");
	    postConnection.setDoOutput(true);
	    OutputStream os = postConnection.getOutputStream();
	    os.write(POST_PARAMS.getBytes());
	    os.flush();
	    os.close();
	    
	    int responseCode = postConnection.getResponseCode();
	    System.out.println("POST Response Code :  " + responseCode);
	    context.getLogger().info("POST Response Code :  " + responseCode);
	    
	    System.out.println("POST Response Message : " + postConnection.getResponseMessage());
	    context.getLogger().info("POST Response Message : " + postConnection.getResponseMessage());
	    
	    StringBuffer response = new StringBuffer();
	    if (responseCode == 200) { //success
	        BufferedReader in = new BufferedReader(new InputStreamReader( postConnection.getInputStream()));
	        String inputLine;
	        while ((inputLine = in .readLine()) != null) {
	            response.append(inputLine);
	        } in .close();

	        // print result
	        System.out.println(response.toString());
	        context.getLogger().info(response.toString());
	        ajaxResponse=response.toString();
	        return ajaxResponse;
	    }else {
	    	 System.out.println("POST To CT Not Worked because response code is not 200 ");
	    	 context.getLogger().info("POST To CT Not Worked because response code is not 200 ");
	    	 return ajaxResponse;
	    }
	    
	    } catch(Exception e) {
	        System.out.println("Exception Occurred "+e);
	        context.getLogger().info("Exception Occurred "+e);
	    }
		return ajaxResponse;
	}

	 private static String getAttributeName(String attributeName, Long index, List<String> replicatedAttribute) {
	        if(replicatedAttribute.contains(attributeName)) {
	            if(index>1)
	                return (attributeName+index);
	        }
	        return attributeName;
	    }
	 
	 public static Double getDouble(Integer value) {
		 try {
			 if(value!=null) {
				 return Double.valueOf(value);
			 }
			 return null;
		 }catch(Exception e) {
			 
			 return null;
		 }
	 }
	 public static Double getDouble(Float value) {
		 try {
			 if(value!=null) {
				 return Double.valueOf(value);
			 }
			 return null;
		 }catch(Exception e) {
			 return null;
		 }
	 }
	 public static Double getDouble(String value) {
		 	try {
			if(value!=null) {
				return Double.valueOf(value);
			}
			 return null;
		 	}catch(Exception e) {
				 return null;
			 }
		 }
	 
	 
	 public static Long getLong(Integer value) {
		 try {
			 if(value!=null) {
				 return Long.valueOf(value);
			 }
			 return null;
		 }catch(Exception e) {
			 return null;
		 }
	 }
	 public static Long getLong(String value) {
		 try {
			if(value!=null) {
				return Long.valueOf(value);
			}
			return null;
		 }catch(Exception e) {
			 return null;
		 }
	 }
		public static String CTEpochformat(Date eventDate) {
			 String date="$D_";
			 date=date+(eventDate.getTime()/1000);
			return date;
		}
	 private static void fetchOdsDataFromResultSet(ResultSet rs, Map<String, Object> map, List<String> replicatedAttribute) throws Exception {
			String ODS_HT_POLICY_START_DATE_FORMAT="dd/MM/yyyy";
			Long index= rs.getLong("INDEX");
			Long index1= rs.getLong("INDEX");
			if(index==null) {
				index=(long) 0;
			}
			if(index1==null) {
				index1=(long) 0;
			}
		    //Long noofpolicies= rs.getLong("NO_OF_POLICIES");
	 		map.put("NO_OF_POLICIES", getLong(rs.getString("NO_OF_POLICIES")));
	 		map.put(getAttributeName("CLIENTCODE",index,replicatedAttribute),rs.getString("CLIENTCODE"));
		    map.put(getAttributeName("MEMBERCODE",index,replicatedAttribute),rs.getString("MEMBERCODE"));
			map.put(getAttributeName("TITLE",index,replicatedAttribute), rs.getString("TITLE"));
			map.put(getAttributeName("GENDER",index,replicatedAttribute), rs.getString("GENDER"));
			if(rs.getDate("DOB")!=null) {
				map.put(getAttributeName("DOB",index,replicatedAttribute),CTEpochformat(rs.getDate("DOB")));}
			map.put(getAttributeName("Occupation",index,replicatedAttribute), rs.getString("Occupation"));
			map.put(getAttributeName("MaritalStatus",index,replicatedAttribute), rs.getString("MaritalStatus"));
			map.put(getAttributeName("CITY",index,replicatedAttribute), rs.getString("CITY"));
			map.put(getAttributeName("DISTRICT",index,replicatedAttribute), rs.getString("DISTRICT"));
			map.put(getAttributeName("STATE",index,replicatedAttribute), rs.getString("STATE"));
			map.put(getAttributeName("BLOODGROUP",index,replicatedAttribute), rs.getString("BLOODGROUP"));
			map.put(getAttributeName("HEIGHT",index,replicatedAttribute), getDouble(rs.getInt("HEIGHT")));
			map.put(getAttributeName("WEIGHT",index,replicatedAttribute), getDouble(rs.getFloat("WEIGHT")));
			map.put(getAttributeName("BMI",index,replicatedAttribute), getDouble(rs.getFloat("BMI")));
			map.put(getAttributeName("ISSmoking",index,replicatedAttribute), rs.getString("ISSmoking"));
			map.put(getAttributeName("ISAlchol",index,replicatedAttribute), rs.getString("ISAlchol"));
			map.put(getAttributeName("ISPanMasalaGutkha",index,replicatedAttribute), rs.getString("ISPanMasalaGutkha"));
			map.put(getAttributeName("Exercise",index,replicatedAttribute), rs.getBoolean("Exercise"));
			map.put(getAttributeName("SportClub",index,replicatedAttribute), rs.getBoolean("SportClub"));
			map.put(getAttributeName("POLICY_NUMBER",index,replicatedAttribute), rs.getString("POLICY_NUMBER"));
			map.put(getAttributeName("TestType",index,replicatedAttribute), rs.getString("TestType"));
			if(rs.getString("POLICY_START_DATE")!=null && !rs.getString("POLICY_START_DATE").isEmpty()) {
				map.put(getAttributeName("POLICY_START_DATE",index,replicatedAttribute),CTEpochformat(convertToDate(rs.getString("POLICY_START_DATE"),ODS_HT_POLICY_START_DATE_FORMAT))) ;}
			if(rs.getDate("POLICY_END_DATE")!=null) {
				map.put(getAttributeName("POLICY_END_DATE",index,replicatedAttribute),CTEpochformat(rs.getDate("POLICY_END_DATE")));}
			map.put(getAttributeName("PRODUCT_NAME",index,replicatedAttribute), rs.getString("PRODUCT_NAME"));
			map.put(getAttributeName("PRODUCT_VARIANT",index,replicatedAttribute), rs.getString("PRODUCT_VARIANT"));
			map.put(getAttributeName("POLICY_VARIANT",index,replicatedAttribute), rs.getString("POLICY_VARIANT"));
			map.put(getAttributeName("PLAN_TYPE",index,replicatedAttribute), rs.getString("PLAN_TYPE"));
			map.put(getAttributeName("SUM_INSURED",index,replicatedAttribute), rs.getDouble("SUM_INSURED"));
			map.put(getAttributeName("FAMILY_TYPE",index,replicatedAttribute), rs.getString("FAMILY_TYPE"));
			map.put(getAttributeName("STP_NSTP",index,replicatedAttribute), rs.getString("STP_NSTP"));
			map.put(getAttributeName("PROPOSAL_SUBSTATUS",index,replicatedAttribute), rs.getString("PROPOSAL_SUBSTATUS"));
			map.put(getAttributeName("BUSINESS_TYPE",index,replicatedAttribute), rs.getString("BUSINESS_TYPE"));
			map.put(getAttributeName("NUMBER_OF_MEMBERS",index,replicatedAttribute), getLong(rs.getInt("NUMBER_OF_MEMBERS")));
			map.put(getAttributeName("Claim No",index,replicatedAttribute), rs.getString("Claim No"));
			if(rs.getDate("DOA")!=null)
				map.put(getAttributeName("DOA",index,replicatedAttribute),CTEpochformat(rs.getDate("DOA"))) ;
			if(rs.getDate("DOD")!=null)
				map.put(getAttributeName("DOD",index,replicatedAttribute),CTEpochformat(rs.getDate("DOD"))) ;
			map.put(getAttributeName("Claim Type",index,replicatedAttribute), rs.getString("Claim Type"));
			map.put(getAttributeName("Claim Status",index,replicatedAttribute), rs.getString("Claim Status"));
			map.put(getAttributeName("Approved Amount",index,replicatedAttribute), rs.getDouble("Approved Amount"));
			map.put(getAttributeName("Hospital Name",index,replicatedAttribute), rs.getString("Hospital Name"));
			map.put(getAttributeName("ICD Chapter",index,replicatedAttribute), rs.getString("ICD Chapter"));
			map.put(getAttributeName("ICD Block",index,replicatedAttribute), rs.getString("ICD Block"));
			map.put(getAttributeName("ICD_Level1",index,replicatedAttribute), rs.getString("ICD Level1"));
			map.put(getAttributeName("ICD_Level2",index,replicatedAttribute), rs.getString("ICD Level2"));
			map.put(getAttributeName("ACTIVEDAYS_CNT",index,replicatedAttribute), getLong(rs.getInt("ACTIVEDAYS_CNT")));
			map.put(getAttributeName("HealthReturn",index,replicatedAttribute), rs.getDouble("HealthReturn"));
			map.put(getAttributeName("HHS",index,replicatedAttribute), rs.getString("HHS"));
			map.put(getAttributeName("Diastolic",index,replicatedAttribute), getDouble(rs.getString("Diastolic")));
			map.put(getAttributeName("Direct Bilirubin",index,replicatedAttribute), getDouble(rs.getString("Direct Bilirubin")));
			map.put(getAttributeName("Direct/Total Bilirubin Ratio",index,replicatedAttribute), getDouble(rs.getString("Direct/Total Bilirubin Ratio")));
			map.put(getAttributeName("Eosinophils",index,replicatedAttribute), getDouble(rs.getString("Eosinophils")));
			map.put(getAttributeName("Eosinophils-Absolute Count",index,replicatedAttribute), getDouble(rs.getString("Eosinophils-Absolute Count")));
			map.put(getAttributeName("Epithelial cells",index,replicatedAttribute), getDouble(rs.getString("Epithelial cells")));
			map.put(getAttributeName("Erythrocyte sedimentation rate (ESR)",index,replicatedAttribute), getDouble(rs.getString("Erythrocyte sedimentation rate (ESR)")));
			map.put(getAttributeName("ESR",index,replicatedAttribute), getDouble(rs.getString("ESR")));
			map.put(getAttributeName("Fasting Blood Sugar",index,replicatedAttribute), getDouble(rs.getString("Fasting Blood Sugar")));
			map.put(getAttributeName("Fasting Blood Sugar mgdl",index,replicatedAttribute), getDouble(rs.getString("Fasting Blood Sugar mgdl")));
			map.put(getAttributeName("Fasting Plasma Glucose",index,replicatedAttribute), getDouble(rs.getString("Fasting Plasma Glucose")));
			map.put(getAttributeName("Gamma Glutamyl Transferase (GGT)",index,replicatedAttribute), getDouble(rs.getString("Gamma Glutamyl Transferase (GGT)")));
			map.put(getAttributeName("Gamma glutamyl transpeptidase (GGT)",index,replicatedAttribute), getDouble(rs.getString("Gamma glutamyl transpeptidase (GGT)")));
			map.put(getAttributeName("GGT",index,replicatedAttribute), getDouble(rs.getString("GGT")));
			map.put(getAttributeName("Globulin",index,replicatedAttribute), getDouble(rs.getString("Globulin")));
			map.put(getAttributeName("Haemoglobin",index,replicatedAttribute), getDouble(rs.getString("Haemoglobin")));
			map.put(getAttributeName("Ham's test (acid serum)",index,replicatedAttribute), getDouble(rs.getString("Ham's test (acid serum)")));
			map.put(getAttributeName("HbA1c",index,replicatedAttribute), getDouble(rs.getString("HbA1c")));
			map.put(getAttributeName("HbA1c - Glycation with D glucose",index,replicatedAttribute), getDouble(rs.getString("HbA1c - Glycation with D glucose")));
			map.put(getAttributeName("HBsAg",index,replicatedAttribute), getDouble(rs.getString("HBsAg")));
			map.put(getAttributeName("HbSAg (Hepatitis B)",index,replicatedAttribute), getDouble(rs.getString("HbSAg (Hepatitis B)")));
			map.put(getAttributeName("HDL",index,replicatedAttribute), getDouble(rs.getString("HDL")));
			map.put(getAttributeName("HDL Cholesterol",index,replicatedAttribute), getDouble(rs.getString("HDL Cholesterol")));
			map.put(getAttributeName("HDL Cholestrol",index,replicatedAttribute), getDouble(rs.getString("HDL Cholestrol")));
			map.put(getAttributeName("HDL/LDL Cholesterol",index,replicatedAttribute), getDouble(rs.getString("HDL/LDL Cholesterol")));
			map.put(getAttributeName("Hematocrit (HCT)",index,replicatedAttribute), getDouble(rs.getString("Hematocrit (HCT)")));
			map.put(getAttributeName("Hemoglobin A",index,replicatedAttribute), getDouble(rs.getString("Hemoglobin A")));
			map.put(getAttributeName("High Density Lipoprotein (HDL)",index,replicatedAttribute), getDouble(rs.getString("High Density Lipoprotein (HDL)")));
			map.put(getAttributeName("Hip",index,replicatedAttribute), getDouble(rs.getString("Hip")));
			map.put(getAttributeName("Hip Measurement",index,replicatedAttribute), getDouble(rs.getString("Hip Measurement")));
			map.put(getAttributeName("Hip Waist Ratio",index,replicatedAttribute), getDouble(rs.getString("Hip Waist Ratio")));
			map.put(getAttributeName("Hyperlipidemia",index,replicatedAttribute), getDouble(rs.getString("Hyperlipidemia")));
			map.put(getAttributeName("Hypertension",index,replicatedAttribute), getDouble(rs.getString("Hypertension")));
			map.put(getAttributeName("Indirect Bilirubin",index,replicatedAttribute), getDouble(rs.getString("Indirect Bilirubin")));
			map.put(getAttributeName("Iron",index,replicatedAttribute), getDouble(rs.getString("Iron")));
			map.put(getAttributeName("Iron binding capacity (TIBC)",index,replicatedAttribute), getDouble(rs.getString("Iron binding capacity (TIBC)")));
			map.put(getAttributeName("Ketone Bodies",index,replicatedAttribute), getDouble(rs.getString("Ketone Bodies")));
			map.put(getAttributeName("Ketones",index,replicatedAttribute), getDouble(rs.getString("Ketones")));
			map.put(getAttributeName("LDL",index,replicatedAttribute), getDouble(rs.getString("LDL")));
			map.put(getAttributeName("LDL Cholesterol",index,replicatedAttribute), getDouble(rs.getString("LDL Cholesterol")));
			map.put(getAttributeName("LDL HDL RATIO",index,replicatedAttribute), getDouble(rs.getString("LDL HDL RATIO")));
			map.put(getAttributeName("LDL/HDL",index,replicatedAttribute), getDouble(rs.getString("LDL/HDL")));
			map.put(getAttributeName("Lipase",index,replicatedAttribute), getDouble(rs.getString("Lipase")));
			map.put(getAttributeName("Low Density Lipoprotein (LDL)",index,replicatedAttribute), getDouble(rs.getString("Low Density Lipoprotein (LDL)")));
			map.put(getAttributeName("Lymphocytes",index,replicatedAttribute), getDouble(rs.getString("Lymphocytes")));
			map.put(getAttributeName("Lymphocytes-Absolute Count",index,replicatedAttribute), getDouble(rs.getString("Lymphocytes-Absolute Count")));
			map.put(getAttributeName("Mean Corpuscular Hemoblogin (MCH)",index,replicatedAttribute), getDouble(rs.getString("Mean Corpuscular Hemoblogin (MCH)")));
			map.put(getAttributeName("Mean Corpuscular Hemoglobin Concentration (MCHC)",index,replicatedAttribute),	getDouble(rs.getString("Mean Corpuscular Hemoglobin Concentration (MCHC)")));
			map.put(getAttributeName("Mean Corpuscular Volume (MCV)",index,replicatedAttribute), getDouble(rs.getString("Mean Corpuscular Volume (MCV)")));
			map.put(getAttributeName("Mean platelet volume (MPV)",index,replicatedAttribute), getDouble(rs.getString("Mean platelet volume (MPV)")));
			map.put(getAttributeName("Microalbumin",index,replicatedAttribute), getDouble(rs.getString("Microalbumin")));
			map.put(getAttributeName("Monocytes",index,replicatedAttribute), getDouble(rs.getString("Monocytes")));
			map.put(getAttributeName("Monocytes-Absolute Count",index,replicatedAttribute), getDouble(rs.getString("Monocytes-Absolute Count")));
			map.put(getAttributeName("Neutrophils",index,replicatedAttribute), getDouble(rs.getString("Neutrophils")));
			map.put(getAttributeName("Neutrophils-Absolute Count",index,replicatedAttribute), getDouble(rs.getString("Neutrophils-Absolute Count")));
			map.put(getAttributeName("Nitrite",index,replicatedAttribute), getDouble(rs.getString("Nitrite")));
			map.put(getAttributeName("Nitrites",index,replicatedAttribute), getDouble(rs.getString("Nitrites")));
			map.put(getAttributeName("Nucleated Red Blood Cells Percentage",index,replicatedAttribute), getDouble(rs.getString("Nucleated Red Blood Cells Percentage")));
			map.put(getAttributeName("Ophthalmology Consultation",index,replicatedAttribute), getDouble(rs.getString("Ophthalmology Consultation")));
			map.put(getAttributeName("Other Conditions",index,replicatedAttribute), getDouble(rs.getString("Other Conditions")));
			map.put(getAttributeName("Packed Cell Volume",index,replicatedAttribute), getDouble(rs.getString("Packed Cell Volume")));
			map.put(getAttributeName("Packed cell volume (PCV)",index,replicatedAttribute), getDouble(rs.getString("Packed cell volume (PCV)")));
			map.put(getAttributeName("Pap Smear",index,replicatedAttribute), getDouble(rs.getString("Pap Smear")));
			map.put(getAttributeName("pH",index,replicatedAttribute), getDouble(rs.getString("pH")));
			map.put(getAttributeName("Phosphorous",index,replicatedAttribute), getDouble(rs.getString("Phosphorous")));
			map.put(getAttributeName("Physician Consultation",index,replicatedAttribute), getDouble(rs.getString("Physician Consultation")));
			map.put(getAttributeName("Physiotherapist",index,replicatedAttribute), getDouble(rs.getString("Physiotherapist")));
			map.put(getAttributeName("Platelet Count",index,replicatedAttribute), getDouble(rs.getString("Platelet Count")));
			map.put(getAttributeName("Platelet Distribution Width (PDW)",index,replicatedAttribute), getDouble(rs.getString("Platelet Distribution Width (PDW)")));
			map.put(getAttributeName("Post-Bronchodilator FEV/FVR",index,replicatedAttribute), getDouble(rs.getString("Post-Bronchodilator FEV/FVR")));
			map.put(getAttributeName("Post-Bronchodilator FEV1",index,replicatedAttribute), getDouble(rs.getString("Post-Bronchodilator FEV1")));
			map.put(getAttributeName("Post-Bronchodilator FVC",index,replicatedAttribute), getDouble(rs.getString("Post-Bronchodilator FVC")));
			map.put(getAttributeName("Postprandial",index,replicatedAttribute), getDouble(rs.getString("Postprandial")));
			map.put(getAttributeName("Potasium",index,replicatedAttribute), getDouble(rs.getString("Potasium")));
			map.put(getAttributeName("Pre-Bronchodilator FEV 1",index,replicatedAttribute), getDouble(rs.getString("Pre-Bronchodilator FEV 1")));
			map.put(getAttributeName("Pre-Bronchodilator FEV/FVR",index,replicatedAttribute), getDouble(rs.getString("Pre-Bronchodilator FEV/FVR")));
			map.put(getAttributeName("Pre-Bronchodilator FVC",index,replicatedAttribute), getDouble(rs.getString("Pre-Bronchodilator FVC")));
			map.put(getAttributeName("Prostate-specific antigen (PSA)",index,replicatedAttribute), getDouble(rs.getString("Prostate-specific antigen (PSA)")));
			map.put(getAttributeName("Protein",index,replicatedAttribute), getDouble(rs.getString("Protein")));
			map.put(getAttributeName("PSA",index,replicatedAttribute), getDouble(rs.getString("PSA")));
			map.put(getAttributeName("PTH",index,replicatedAttribute), getDouble(rs.getString("PTH")));
			map.put(getAttributeName("Pulmonary Function Test",index,replicatedAttribute), getDouble(rs.getString("Pulmonary Function Test")));
			map.put(getAttributeName("Pus cells",index,replicatedAttribute), getDouble(rs.getString("Pus cells")));
			map.put(getAttributeName("R.B.C",index,replicatedAttribute), getDouble(rs.getString("R.B.C")));
			map.put(getAttributeName("Random Blood Sugar",index,replicatedAttribute), getDouble(rs.getString("Random Blood Sugar")));
			map.put(getAttributeName("Reaction.pH",index,replicatedAttribute), getDouble(rs.getString("Reaction.pH")));
			map.put(getAttributeName("Red Blood Cells",index,replicatedAttribute), getDouble(rs.getString("Red Blood Cells")));
			map.put(getAttributeName("Red Cell Count",index,replicatedAttribute), getDouble(rs.getString("Red Cell Count")));
			map.put(getAttributeName("Rheumatoid factor Test",index,replicatedAttribute), getDouble(rs.getString("Rheumatoid factor Test")));
			map.put(getAttributeName("Serum Albumin",index,replicatedAttribute), getDouble(rs.getString("Serum Albumin")));
			map.put(getAttributeName("Serum Bicarbonate",index,replicatedAttribute), getDouble(rs.getString("Serum Bicarbonate")));
			map.put(getAttributeName("Serum Calcium",index,replicatedAttribute), getDouble(rs.getString("Serum Calcium")));
			map.put(getAttributeName("Serum Chloride",index,replicatedAttribute), getDouble(rs.getString("Serum Chloride")));
			map.put(getAttributeName("Serum Creatinine",index,replicatedAttribute), getDouble(rs.getString("Serum Creatinine")));
			map.put(getAttributeName("Serum Electrolytes",index,replicatedAttribute), getDouble(rs.getString("Serum Electrolytes")));
			map.put(getAttributeName("Serum Globulin",index,replicatedAttribute), getDouble(rs.getString("Serum Globulin")));
			map.put(getAttributeName("Serum Magnesium",index,replicatedAttribute), getDouble(rs.getString("Serum Magnesium")));
			map.put(getAttributeName("Serum Potassium",index,replicatedAttribute), getDouble(rs.getString("Serum Potassium")));
			map.put(getAttributeName("Serum Sodium",index,replicatedAttribute), getDouble(rs.getString("Serum Sodium")));
			map.put(getAttributeName("Serum Uric Acid",index,replicatedAttribute), getDouble(rs.getString("Serum Uric Acid")));
			map.put(getAttributeName("SGOT",index,replicatedAttribute), getDouble(rs.getString("SGOT")));
			map.put(getAttributeName("Smoking Status",index,replicatedAttribute), rs.getString("Smoking Status"));
			map.put(getAttributeName("Sodium",index,replicatedAttribute), getDouble(rs.getString("Sodium")));
			map.put(getAttributeName("Specific Gravity",index,replicatedAttribute), getDouble(rs.getString("Specific Gravity")));
			map.put(getAttributeName("Sucrose hemolysis Test",index,replicatedAttribute), getDouble(rs.getString("Sucrose hemolysis Test")));
			map.put(getAttributeName("Sugar (Glucose)",index,replicatedAttribute), getDouble(rs.getString("Sugar (Glucose)")));
			map.put(getAttributeName("Sugar/glucose",index,replicatedAttribute), getDouble(rs.getString("Sugar/glucose")));
			map.put(getAttributeName("Systolic",index,replicatedAttribute), getDouble(rs.getString("Systolic")));
			map.put(getAttributeName("T3",index,replicatedAttribute), getDouble(rs.getString("T3")));
			map.put(getAttributeName("T4",index,replicatedAttribute), getDouble(rs.getString("T4")));
			map.put(getAttributeName("TMT",index,replicatedAttribute), getDouble(rs.getString("TMT")));
			map.put(getAttributeName("Tobacco (Number of units per day)",index,replicatedAttribute), getDouble(rs.getString("Tobacco (Number of units per day)")));
			map.put(getAttributeName("Tobacco status",index,replicatedAttribute), getDouble(rs.getString("Tobacco status")));
			map.put(getAttributeName("Total Bilirubin",index,replicatedAttribute), getDouble(rs.getString("Total Bilirubin")));
			map.put(getAttributeName("Total cholesterol",index,replicatedAttribute), getDouble(rs.getString("Total cholesterol")));
			map.put(getAttributeName("Total Cholesterol/HDL Ratio",index,replicatedAttribute), getDouble(rs.getString("Total Cholesterol/HDL Ratio")));
			map.put(getAttributeName("Total protein",index,replicatedAttribute), getDouble(rs.getString("Total protein")));
			map.put(getAttributeName("Total Serum Protein",index,replicatedAttribute), getDouble(rs.getString("Total Serum Protein")));
			map.put(getAttributeName("Total WBC count",index,replicatedAttribute), getDouble(rs.getString("Total WBC count")));
			map.put(getAttributeName("Total White Cell Count",index,replicatedAttribute), getDouble(rs.getString("Total White Cell Count")));
			map.put(getAttributeName("Trichomonas Vaginalis",index,replicatedAttribute), getDouble(rs.getString("Trichomonas Vaginalis")));
			map.put(getAttributeName("Triglycerides",index,replicatedAttribute), getDouble(rs.getString("Triglycerides")));
			map.put(getAttributeName("TSH",index,replicatedAttribute), getDouble(rs.getString("TSH")));
			map.put(getAttributeName("Ultrasound Abdomen",index,replicatedAttribute), getDouble(rs.getString("Ultrasound Abdomen")));
			map.put(getAttributeName("Urine Mircoalbumin",index,replicatedAttribute), getDouble(rs.getString("Urine Mircoalbumin")));
			map.put(getAttributeName("Urine Protein",index,replicatedAttribute), getDouble(rs.getString("Urine Protein")));
			map.put(getAttributeName("Urobilinogen",index,replicatedAttribute), getDouble(rs.getString("Urobilinogen")));
			map.put(getAttributeName("USG -Abdomen and Pelvis",index,replicatedAttribute), getDouble(rs.getString("USG -Abdomen and Pelvis")));
			map.put(getAttributeName("Very Low Density Lipoprotein (VLDL)",index,replicatedAttribute), getDouble(rs.getString("Very Low Density Lipoprotein (VLDL)")));
			map.put(getAttributeName("Vitamin B12",index,replicatedAttribute), getDouble(rs.getString("Vitamin B12")));
			map.put(getAttributeName("Vitamin D",index,replicatedAttribute), getDouble(rs.getString("Vitamin D")));
			map.put(getAttributeName("VLDL",index,replicatedAttribute), getDouble(rs.getString("VLDL")));
			map.put(getAttributeName("VLDL Cholesterol",index,replicatedAttribute), getDouble(rs.getString("VLDL Cholesterol")));
			map.put(getAttributeName("Waist",index,replicatedAttribute), getDouble(rs.getString("Waist")));
			map.put(getAttributeName("Waist measurement",index,replicatedAttribute), getDouble(rs.getString("Waist measurement")));
			map.put(getAttributeName("Yeast",index,replicatedAttribute), getDouble(rs.getString("Yeast")));
			map.put(getAttributeName("Yeast Cells",index,replicatedAttribute), getDouble(rs.getString("Yeast Cells")));
			map.put(getAttributeName("Whatactivitiesareyoudoingforbeinghealthy",index,replicatedAttribute), rs.getString("Whatactivitiesareyoudoingforbeinghealthy"));
			map.put(getAttributeName("preferredlanguage",index,replicatedAttribute), rs.getString("preferredlanguage"));
			map.put(getAttributeName("preferredcommunicationmode",index,replicatedAttribute), rs.getString("preferredcommunicationmode"));
			if(rs.getDate("CreatedDate")!=null) {
				map.put(getAttributeName("CreatedDate",index,replicatedAttribute),CTEpochformat(rs.getDate("CreatedDate"))) ;}
			map.put(getAttributeName("FIRSTNAME",index,replicatedAttribute), rs.getString("FIRSTNAME"));
			map.put(getAttributeName("MIDDLENAME",index,replicatedAttribute), rs.getString("MIDDLENAME"));
			map.put(getAttributeName("LASTNAME",index,replicatedAttribute), rs.getString("LASTNAME"));
			
			map.put("Phone", "+91"+rs.getString("CONTACTMOBILE"));

			map.put(getAttributeName("EMAIL",index,replicatedAttribute), rs.getString("EMAIL"));    

			
			if(rs.getString("FIRSTNAME")!=null && rs.getString("LASTNAME")!=null) {
			map.put(getAttributeName("Name",index,replicatedAttribute), rs.getString("FIRSTNAME")+" "+rs.getString("LASTNAME"));}
			
			map.put(getAttributeName("MSG-whatsapp",index,replicatedAttribute), Boolean.parseBoolean("TRUE"));
			//new changes
			map.put(getAttributeName("PROPOSAL_SUBSTATUS",index,replicatedAttribute), rs.getString("PROPOSAL_SUBSTATUS"));
			map.put(getAttributeName("IS_PROPOSER",index,replicatedAttribute), rs.getString("IS_PROPOSER"));
			map.put(getAttributeName("NET_PREMIUM",index,replicatedAttribute), getDouble(rs.getString("NET PREMIUM")));
			map.put(getAttributeName("AUTODEBIT",index,replicatedAttribute), rs.getString("AUTODEBIT"));
			map.put(getAttributeName("Channel",index,replicatedAttribute), rs.getString("Channel"));
			map.put(getAttributeName("ParentServiceProviderName",index,replicatedAttribute), rs.getString("ParentServiceProviderName"));
			map.put(getAttributeName("IntermediaryName",index,replicatedAttribute), rs.getString("IntermediaryName"));
			map.put(getAttributeName("IntermediaryCode",index,replicatedAttribute), rs.getString("IntermediaryCode"));
			map.put(getAttributeName("IntermediaryCategory",index,replicatedAttribute), rs.getString("IntermediaryCategory"));
			
			//ashwini new fields added from here
			map.put(getAttributeName("Cluster_Rev_New",index,replicatedAttribute), rs.getString("Cluster_Rev_New"));
			map.put(getAttributeName("HA_Decile",index,replicatedAttribute), rs.getFloat("HA_Decile"));
			map.put(getAttributeName("HA_HML",index,replicatedAttribute), rs.getString("HA_HML"));
			map.put(getAttributeName("APP_Decile",index,replicatedAttribute), rs.getInt("APP_Decile"));
			map.put(getAttributeName("APP_HML",index,replicatedAttribute), rs.getString("APP_HML"));
			map.put(getAttributeName("AD_Decile",index,replicatedAttribute), rs.getInt("AD_Decile"));
			map.put(getAttributeName("AD_HML",index,replicatedAttribute), rs.getString("AD_HML"));
			map.put(getAttributeName("CONTACTMOBILE_1",index,replicatedAttribute), rs.getString("CONTACTMOBILE"));
			map.put(getAttributeName("USEREMAIL_1",index,replicatedAttribute), rs.getString("EMAIL"));
			map.put(getAttributeName("PAYMENT_LINK",index,replicatedAttribute), rs.getString("PAYMENT_LINK"));
			map.put(getAttributeName("renewalnotice_link",index,replicatedAttribute), rs.getString("renewalnotice_link"));
			
			map.put(getAttributeName("Relation with proposer",index,replicatedAttribute), rs.getString("Relation with proposer"));
			map.put(getAttributeName("Age_1",index,replicatedAttribute), rs.getInt("Age"));
			map.put(getAttributeName("WBS",index,replicatedAttribute), rs.getString("WBS"));
			map.put(getAttributeName("HA Done",index,replicatedAttribute), rs.getString("HA Done"));
			map.put(getAttributeName("HHS (Healthy Heart Score) Received",index,replicatedAttribute), rs.getString("HHS (Healthy Heart Score) Received"));
			map.put(getAttributeName("FA Done",index,replicatedAttribute), rs.getString("FA Done"));
			
			if(rs.getDate("HHS Expiry Date")!=null) {
				map.put(getAttributeName("HHS Expiry Date",index,replicatedAttribute),CTEpochformat(rs.getDate("HHS Expiry Date"))) ;}
			if(rs.getDate("FA Received")!=null) {
				map.put(getAttributeName("FA Received",index,replicatedAttribute),CTEpochformat(rs.getDate("FA Received"))) ;}	
			if(rs.getDate("Claims Raised Date")!=null) {
				map.put(getAttributeName("Claims Raised Date",index,replicatedAttribute),CTEpochformat(rs.getDate("Claims Raised Date"))) ;}	
			if(rs.getDate("Date of Disbursement")!=null) {
				map.put(getAttributeName("Date of Disbursement",index,replicatedAttribute),CTEpochformat(rs.getDate("Date of Disbursement"))) ;}
			
			map.put(getAttributeName("Claims Amount",index,replicatedAttribute), rs.getFloat("Claims Amount"));
			map.put(getAttributeName("Cover Name",index,replicatedAttribute), rs.getString("Cover Name"));
			map.put(getAttributeName("Intimation Type",index,replicatedAttribute), rs.getString("Intimation Type"));
			map.put(getAttributeName("PED",index,replicatedAttribute), rs.getString("PED"));
			map.put(getAttributeName("PLAN_CD",index,replicatedAttribute), rs.getString("PLAN_CD"));
			map.put(getAttributeName("Principal_Member_ID",index,replicatedAttribute), rs.getString("Principal_Member_ID"));
			map.put(getAttributeName("CONTRACT_NO",index,replicatedAttribute), rs.getString("CONTRACT_NO"));
			map.put(getAttributeName("Principal_Member_Name",index,replicatedAttribute), rs.getString("Principal_Member_Name"));
			map.put(getAttributeName("CategoryCohortID",index,replicatedAttribute), rs.getInt("CategoryCohortID"));
			map.put(getAttributeName("Wellness_Score",index,replicatedAttribute), rs.getInt("Wellness_Score"));
			map.put(getAttributeName("Peer_Group_Score",index,replicatedAttribute), rs.getInt("Peer_Group_Score"));
			map.put(getAttributeName("Full_Potential_Score",index,replicatedAttribute), rs.getInt("Full_Potential_Score"));
			map.put(getAttributeName("Risk",index,replicatedAttribute), rs.getInt("Risk"));
			//map.put(getAttributeName("Category_Index",index,replicatedAttribute), rs.getInt("Category_Index"));
			//map.put(getAttributeName("Risk_Category_Index",index,replicatedAttribute), rs.getInt("Risk_Category_Index"));
			map.put(getAttributeName("Category",index1,replicatedAttribute), rs.getString("Category"));
			map.put(getAttributeName("Risk_Category",index1,replicatedAttribute), rs.getString("Risk_Category"));
			map.put(getAttributeName("patientremoteid",index,replicatedAttribute), rs.getString("patientremoteid"));
			if(rs.getDate("ScoreDate")!=null) {
				map.put(getAttributeName("ScoreDate",index,replicatedAttribute),CTEpochformat(rs.getDate("ScoreDate"))) ;}
			map.put(getAttributeName("Expiry_Flag",index,replicatedAttribute), rs.getString("Expiry_Flag"));
			
			
		}
		
		public static Date convertToDate(String inputDate, String format) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat(format);
				return sdf.parse(inputDate.trim());
			} catch (ParseException e) {
				System.out.println("Error in parsing date :"+e);
				//LOGGER.error("Error in parsing date :", e);
			}
			return null;
		}

		public static String convertToString(Date inputDate, String format) {
			DateFormat dateFormat = new SimpleDateFormat(format);
			return dateFormat.format(inputDate);
		}

		public static String convertToString(Timestamp inputDate, String format) {
			DateFormat dateFormat = new SimpleDateFormat(format);
			return dateFormat.format(inputDate);
		}

		

}

