package ODSData.Request;

import java.util.List;

public class ClevertapUploadUserPropertyRequest {
	private List<ClevertapUserPropertyData> d;

	public List<ClevertapUserPropertyData> getD() {
		return d;
	}

	public void setD(List<ClevertapUserPropertyData> d) {
		this.d = d;
	}
}
