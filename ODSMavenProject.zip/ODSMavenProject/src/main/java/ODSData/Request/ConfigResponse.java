package ODSData.Request;

import java.util.ArrayList;

public class ConfigResponse {
	public String status;
    public String messageCode;
    public String messageDesc;
    public String serviceMessageType;
    public ArrayList<Config> configs;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessageCode() {
		return messageCode;
	}
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}
	public String getMessageDesc() {
		return messageDesc;
	}
	public void setMessageDesc(String messageDesc) {
		this.messageDesc = messageDesc;
	}
	public String getServiceMessageType() {
		return serviceMessageType;
	}
	public void setServiceMessageType(String serviceMessageType) {
		this.serviceMessageType = serviceMessageType;
	}
	public ArrayList<Config> getConfigs() {
		return configs;
	}
	public void setConfigs(ArrayList<Config> configs) {
		this.configs = configs;
	}
    
    
}
