package ODSData.Request;

public class AdminConfig {
private Long id;
    
    
    private String configKey;
    
    
    private String CONFIG_VALUE;

    private boolean ENCRYPTED;
    
    public AdminConfig( ) {}
    
    public AdminConfig(String configKey, String CONFIG_VALUE, boolean ENCRYPTED ) {
        this.configKey = configKey;
        this.CONFIG_VALUE = CONFIG_VALUE;
        this.ENCRYPTED = ENCRYPTED;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getConfigKey() {
		return configKey;
	}

	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}

	public String getCONFIG_VALUE() {
		return CONFIG_VALUE;
	}

	public void setCONFIG_VALUE(String cONFIG_VALUE) {
		CONFIG_VALUE = cONFIG_VALUE;
	}

	public boolean isENCRYPTED() {
		return ENCRYPTED;
	}

	public void setENCRYPTED(boolean eNCRYPTED) {
		ENCRYPTED = eNCRYPTED;
	}
    
}
