package ODSData.Request;

import java.util.Map;

public class PushUserPropertiesRequest {

	private String customerId;

	private String memberReferenceNumber;
	private String source;

	private Map<String, Object> data;

	
	
	
	

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getMemberReferenceNumber() {
		return memberReferenceNumber;
	}

	public void setMemberReferenceNumber(String memberReferenceNumber) {
		this.memberReferenceNumber = memberReferenceNumber;
	}

	public Map<String, Object> getData() {
		return data;
	}

	public void setData(Map<String, Object> data) {
		this.data = data;
	}

}
